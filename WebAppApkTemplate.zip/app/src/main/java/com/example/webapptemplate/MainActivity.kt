package com.example.webapptemplate

import android.annotation.SuppressLint
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

/**
 * Minimal template activity.
 *
 * This is the placeholder that later gets swapped, per generated app, with:
 *  - a remote start URL (webView.loadUrl("https://...")), or
 *  - a bundled local web app (webView.loadUrl("file:///android_asset/index.html"))
 *
 * For now it always loads the bundled assets/index.html placeholder page,
 * just to prove the template compiles, builds, signs, and installs.
 */
class MainActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val webView = WebView(this)
        setContentView(webView)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()

        webView.loadUrl("file:///android_asset/index.html")
    }
}
